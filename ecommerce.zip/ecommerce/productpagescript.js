
//Sample product data (replace it with your actual data)
var itemsInCart = [];
var productsList = [];

//function to get products from database
function getProducts(){
    var url = 'http://localhost:9090/getProducts';

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure it: specify the type of request and the URL
    xhr.open('GET', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up a callback function to handle the response
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            // Handle the response from the server
            productsList = response.map(product => ({
                id: product.productId,
                name: product.productName,
                price: `$${product.productPrice}`,
                description: product.productDescription,
                image: product.productImage
             }));
             console.log(productsList);
             renderProducts();
        } else {
            console.error('Request failed with status:', xhr.status);
        }
    };

    // Set up a callback function to handle network errors
    xhr.onerror = function() {
        console.error('Network error occurred');
    };

    // Send the request
    xhr.send();
}

// Function to render products on the page
function renderProducts() {
    console.log("rendering");
    const productList = document.getElementById("productList");

    productsList.forEach(product => {
        const productItem = document.createElement("div");
        productItem.classList.add("product");

        const productImage = document.createElement("img");
        productImage.src = product.image;
        productImage.alt = product.name;

        const productInfo = document.createElement("div");
        productInfo.classList.add("product-info");

        const productName = document.createElement("h2");
        productName.textContent = product.name;



        const productPrice = document.createElement("p");
        productPrice.textContent = `Price: ${product.price}`;

        const addToCartButton = document.createElement("button");
        addToCartButton.classList.add("button");
        addToCartButton.textContent = "Add to Cart";

        // Add click event to the "Add to Cart" button (replace with your actual logic)
        addToCartButton.addEventListener("click", () => {

            if(itemsInCart.includes(product.id)){
                removeItemFromCart(product.id);
                addToCartButton.textContent = "Add to Cart";
                addToCartButton.style.backgroundColor = "#007BFF";
            }else{
                addItemToCart(product.id);
                addToCartButton.textContent = "Remove From Cart";
                addToCartButton.style.backgroundColor = "red";
            }

        });

        const productDescription = document.createElement("p");
        productDescription.textContent = product.description;

        // Append elements to the product item
        productInfo.appendChild(productName);
        productInfo.appendChild(productDescription)
        productInfo.appendChild(productPrice);
        productItem.appendChild(productImage);
        productItem.appendChild(productInfo);
        productItem.appendChild(addToCartButton);

        // Append the product item to the product list
        productList.appendChild(productItem);
    });
}

// Function to update the cart count
function updateCartCount(count) {
    const cartCount = document.getElementById("cartCount");
    cartCount.textContent = count;
}

// Function to add an item to the cart
function addItemToCart(productId) {
    // Simulate adding an item to the cart (replace with your actual logic)
    itemsInCart.push(productId)
    const currentCount = parseInt(document.getElementById("cartCount").textContent, 10);
    const newCount = currentCount + 1;
    updateCartCount(newCount);
}

//function to remove an item from the cart
function removeItemFromCart(productId){
        // Simulate adding an item to the cart (replace with your actual logic)
        itemsInCart.pop(productId);
        const currentCount = parseInt(document.getElementById("cartCount").textContent, 10);
        const newCount = currentCount - 1;
        updateCartCount(newCount);
}

// Call the renderProducts function when the page loads
window.onload = function () {
   userId =  localStorage.getItem("userId");
    displayUsername(userId);
    getProducts();
};

function displayUsername(userId){
    var url = `http://localhost:9090/getUserName?userId=${userId}`;

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure it: specify the type of request and the URL
    xhr.open('GET', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up a callback function to handle the response
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            var username = document.getElementById("username");
            username.textContent = xhr.responseText;
             console.log(xhr.responseText);
        } else {
            console.error('Request failed with status:', xhr.status);
        }
    };

    // Set up a callback function to handle network errors
    xhr.onerror = function() {
        console.error('Network error occurred');
    };

    // Send the request
    xhr.send();
}

// Function to handle scrolling and fix the navbar position
window.onscroll = function() {
    fixNavbar();
};

function fixNavbar() {
    const navbar = document.getElementById("navbar");
    const scrollPosition = window.scrollY;

    if (scrollPosition > 50) {
        navbar.style.backgroundColor = "#444"; // Change the background color on scroll
        navbar.style.boxShadow = "0 2px 4px rgba(0, 0, 0, 0.1)";
    } else {
        navbar.style.backgroundColor = "#333"; // Restore the original background color
        navbar.style.boxShadow = "0 4px 6px rgba(0, 0, 0, 0.1)";
    }
}

function displayCart(){
    localStorage.setItem('itemsInCart' , JSON.stringify(itemsInCart));
    window.location.href =  "cartpage.html";
}


function logout(){
    var logout = document.getElementById("logout");
    localStorage.clear();
    window.location.href = 'login.html';
}