package com.psl.ecommerce.service;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.psl.ecommerce.DTO.OrderRequest;
import com.psl.ecommerce.model.Orders;
import com.psl.ecommerce.model.Product;
import com.psl.ecommerce.model.User;
import com.psl.ecommerce.repository.ProductRepo;
import com.psl.ecommerce.repository.UserRepo;
import com.psl.ecommerce.repository.OrdersRepo;

@Service
public class UserService {
	
	@Autowired
	UserRepo UserRepo;
	
	@Autowired
	ProductRepo ProductRepo;
	
	@Autowired
	OrdersRepo OrdersRepo;
	
	public ResponseEntity<Object> checkCredentials(String username, String password) {
		String storedpass = UserRepo.getPassword(username);
		Map<Object, Object> response = new HashMap<>();
		if(storedpass.equals(password)) {
			response.put("message", "login successful");
			response.put("id", UserRepo.getIdbyUsername(username));
			return ResponseEntity.status(200).body(response);
		}else {
			response.put("message", "Username and password don't match");
			return ResponseEntity.status(200).body(response);		
		}
	}

	public User registerUser(User user) {
		return this.UserRepo.save(user);
	}

	public List<Product> getProductList() {
		return this.ProductRepo.findAll();
	}

	public List<Orders> getOrderList() {
		return this.OrdersRepo.findAll();
	}

	public void createOrder(OrderRequest request) {
		Optional<User> user = this.UserRepo.findById(request.getUserId());
		Orders order = new Orders(user.get(), request.getProductList());
		System.out.println(OrdersRepo.save(order).getProductList());
	}

	public void addProduct(Product product) {
	}

	public String getUserName(Long id) {
		return this.UserRepo.getUserName(id);
	}

	public Product getProductById(Long id) {
		return this.ProductRepo.getProductById(id);
	}
	

}
