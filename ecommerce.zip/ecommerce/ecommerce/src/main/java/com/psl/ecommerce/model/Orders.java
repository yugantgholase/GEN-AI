package com.psl.ecommerce.model;

import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;

@Entity
public class Orders {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
	
    @ElementCollection
    @CollectionTable(name = "order_product", joinColumns = @JoinColumn(name = "order_id"))
    @Column(name = "product_id")
    private List<Long> productList;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Long> getProductList() {
		return productList;
	}

	public void setProductList(List<Long> productList) {
		this.productList = productList;
	}

	public Orders(User user, List<Long> productList) {
		super();
		this.user = user;
		this.productList = productList;
	}
	
	public Orders() {
		
	}
	
}
