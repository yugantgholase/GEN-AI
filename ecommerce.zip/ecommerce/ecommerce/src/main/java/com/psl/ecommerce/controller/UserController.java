package com.psl.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.psl.ecommerce.DTO.OrderRequest;
import com.psl.ecommerce.model.Orders;
import com.psl.ecommerce.model.Product;
import com.psl.ecommerce.model.User;
import com.psl.ecommerce.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService service;
	
	
	@GetMapping("/checkCredentials")
	public ResponseEntity<Object> login(@RequestParam("username") String username, @RequestParam("password") String password){
		System.out.println(username + " " + password);
		return service.checkCredentials(username, password);
	}
	
	@PostMapping("/registerUser")
	public Boolean registerUser(@RequestBody User user) {
		this.service.registerUser(user);
		return true;
	}
	
	@GetMapping("/getProducts")
	public List<Product> getProducts(){
		return this.service.getProductList();
	}

	@GetMapping("getOrders")
	public List<Orders> getOrders(){
		return this.service.getOrderList();
	}
	
	@PostMapping("/createOrder")
	public void createOrder(@RequestBody OrderRequest request) {
		System.out.println(request);
		 this.service.createOrder(request);
	}

	@PostMapping("/addProduct")
	public void addProduct(@RequestBody Product product) {
		 this.service.addProduct(product);
	}
	
	@GetMapping("getUserName")
	public String getUserName(@RequestParam("userId") Long id) {
		return this.service.getUserName(id);
	}
	
	@GetMapping("getProductById")
	public Product getProductById(@RequestParam("id") Long id) {
		return this.service.getProductById(id);
	}
}
