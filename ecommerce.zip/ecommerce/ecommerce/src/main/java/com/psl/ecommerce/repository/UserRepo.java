package com.psl.ecommerce.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.psl.ecommerce.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long>{	
	
	
	@Query(value = "select password from User u where u.username =:username", nativeQuery = true)
	String getPassword(@Param("username") String username);
	
	
	@Query(value = "select id from User u where u.username =:username", nativeQuery = true)
	String getIdbyUsername(@Param("username") String username);


	@Query(value = "select username from User u where u.id =:id", nativeQuery = true)
	String getUserName(@Param("id") Long id);
}


