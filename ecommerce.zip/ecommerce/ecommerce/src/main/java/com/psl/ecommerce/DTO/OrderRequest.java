package com.psl.ecommerce.DTO;

import java.util.List;

public class OrderRequest {

    private Long userId;
    private List<Long> productList;

    // Constructors, getters, and setters

    public OrderRequest() {
    }

    public OrderRequest(Long userId, List<Long> productList) {
        this.userId = userId;
        this.productList = productList;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public List<Long> getProductList() {
        return productList;
    }

    public void setProductList(List<Long> productList) {
        this.productList = productList;
    }
}
