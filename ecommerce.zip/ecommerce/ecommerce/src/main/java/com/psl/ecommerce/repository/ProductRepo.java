package com.psl.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.psl.ecommerce.model.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product, Long>{

	@Query(value = "select *from Product p where p.product_id =:id", nativeQuery = true)
	Product getProductById(@Param("id") Long id);

}