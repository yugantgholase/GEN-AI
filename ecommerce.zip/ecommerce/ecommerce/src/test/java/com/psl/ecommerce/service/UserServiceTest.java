package com.psl.ecommerce.service;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;

import com.psl.ecommerce.DTO.OrderRequest;
import com.psl.ecommerce.model.Orders;
import com.psl.ecommerce.model.Product;
import com.psl.ecommerce.model.User;
import com.psl.ecommerce.repository.OrdersRepo;
import com.psl.ecommerce.repository.ProductRepo;
import com.psl.ecommerce.repository.UserRepo;

class UserServiceTest {

    @Mock
    private UserRepo userRepo;

    @Mock
    private ProductRepo productRepo;

    @Mock
    private OrdersRepo ordersRepo;

    @InjectMocks
    private UserService userService;

    @Test
    void testCheckCredentials_SuccessfulLogin() {
        // Mocking the behavior of the UserRepo
        when(userRepo.getPassword("testUser")).thenReturn("testPassword");
        when(userRepo.getIdbyUsername("testUser")).thenReturn("1");

        ResponseEntity<Object> response = userService.checkCredentials("testUser", "testPassword");

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("message"));
        assertTrue(response.getBody().containsKey("id"));
        assertEquals("login successful", response.getBody().get("message"));
        assertEquals(1L, response.getBody().get("id"));
    }

    @Test
    void testCheckCredentials_FailedLogin() {
        // Mocking the behavior of the UserRepo
        when(userRepo.getPassword("testUser")).thenReturn("incorrectPassword");

        ResponseEntity<Object> response = userService.checkCredentials("testUser", "testPassword");

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().containsKey("message"));
        assertFalse(response.getBody().containsKey("id"));
        assertEquals("Username and password don't match", response.getBody().get("message"));
    }

    @Test
    void testRegisterUser() {
        User testUser = new User();
        when(userRepo.save(testUser)).thenReturn(testUser);

        User savedUser = userService.registerUser(testUser);

        assertNotNull(savedUser);
        assertEquals(testUser, savedUser);
    }

    @Test
    void testGetProductList() {
        List<Product> mockProductList = Arrays.asList(new Product(), new Product());
        when(productRepo.findAll()).thenReturn(mockProductList);

        List<Product> productList = userService.getProductList();

        assertNotNull(productList);
        assertEquals(mockProductList.size(), productList.size());
    }

    @Test
    void testGetOrderList() {
        List<Orders> mockOrderList = Arrays.asList(new Orders(), new Orders());
        when(ordersRepo.findAll()).thenReturn(mockOrderList);

        List<Orders> orderList = userService.getOrderList();

        assertNotNull(orderList);
        assertEquals(mockOrderList.size(), orderList.size());
    }

    @Test
    void testCreateOrder() {
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setUserId(1L);
        orderRequest.setProductList(Arrays.asList(1L, 2L));

        User mockUser = new User();
        when(userRepo.findById(1L)).thenReturn(Optional.of(mockUser));

        userService.createOrder(orderRequest);

        // Add more assertions based on the behavior of your method
    }

    @Test
    void testGetUserName() {
        when(userRepo.getUserName(1L)).thenReturn("testUser");

        String userName = userService.getUserName(1L);

        assertEquals("testUser", userName);
    }

    @Test
    void testGetProductById() {
        Product mockProduct = new Product();
        when(productRepo.getProductById(1L)).thenReturn(mockProduct);

        Product product = userService.getProductById(1L);

        assertEquals(mockProduct, product);
    }
}
