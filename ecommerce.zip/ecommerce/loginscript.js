//function to login
function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (!username || !password) {
        alert("Please enter both username and password.");
        return;
    }
    // Construct the URL with parameters
    var url = 'http://localhost:9090/checkCredentials?username=' + username + '&password=' + password;

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure it: specify the type of request and the URL
    xhr.open('GET', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Set up a callback function to handle the response
    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 300) {
            var response = JSON.parse(xhr.responseText);
            if(response.message === "login successful"){
                localStorage.setItem("userId", response.id);
                window.location.href = "productpage.html";
            }
        } else {
            console.error('Request failed with status:', xhr.status);
        }
    };

    // Set up a callback function to handle network errors
    xhr.onerror = function() {
        console.error('Network error occurred');
    };

    // Send the request
    xhr.send();
}



function showRegisterForm() {
    document.getElementById("loginContainer").classList.add("hidden");
    document.getElementById("registerContainer").classList.remove("hidden");
}

function showLoginForm() {
    document.getElementById("registerContainer").classList.add("hidden");
    document.getElementById("loginContainer").classList.remove("hidden");
}

//function to register
function register() {
    var regUsername = document.getElementById("regUsername").value;
    var regEmail = document.getElementById("regEmail").value;
    var regPassword = document.getElementById("regPassword").value;
    var regConfirmPassword = document.getElementById("regConfirmPassword").value;

    // Check if any field is empty
    if (!regUsername || !regEmail || !regPassword || !regConfirmPassword) {
        alert("Please fill in all fields.");
        return;
    }

    // Check if passwords match
    if (regPassword === regConfirmPassword) {
        var url = `http://localhost:9090/registerUser`;

        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();
        const data = {"username" : regUsername, "email" : regEmail, "password" : regPassword}
        const requestBody = JSON.stringify(data);
        // Configure it: specify the type of request and the URL
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/json');
    
        // // Set up a callback function to handle the response
        // xhr.onload = function() {
        //     if (xhr.status >= 200 && xhr.status < 300) {
        //          return 
        //     } else {
        //         console.error('Request failed with status:', xhr.status);
        //         return null;
        //     }
        // };
    
        // Set up a callback function to handle network errors
        xhr.onerror = function() {
            console.error('Network error occurred');
        };
    
        // Send the request
        xhr.send(requestBody);
        showLoginForm()
    } else {
        alert("Passwords do not match. Please try again.");
    }
}
