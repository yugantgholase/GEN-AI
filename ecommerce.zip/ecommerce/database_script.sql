create database ecommerce;
use ecommerce;

show tables;
desc product;
desc user;
select *from user;
select *from product;
select *from orders;
select *from order_product;

insert into user values(1, "yugantgholase27@gmail.com", "yugant@12", "yugantgholase");

insert into product(product_id, product_description, product_name , product_price, product_image)
values(1, "Powerful A15 Bionic chip, Super Retina XDR display, and advanced dual-camera system for an immersive experience", "Iphone 13", "799", "https://encrypted-tbn3.gstatic.com/shopping?q=tbn:ANd9GcSpAi17bPoIPrbOKQnDcI8ymBOq3hFD-wFvh6E4B8UR9n7IBwg&usqp=CAc");


insert into product(product_id, product_description, product_name , product_price, product_image)
values(2, "ProMotion display, triple-camera system with LiDAR, and A15 Bionic chip for a professional-grade mobile experience", "Iphone 13 pro", "999", "https://rukminim2.flixcart.com/image/850/1000/ktketu80/mobile/a/e/g/iphone-13-pro-mlvw3hn-a-apple-original-imag6vpcvspnzyfy.jpeg?q=20&crop=false");