

// Sample items in the cart (product IDs)
//const itemsInCart = [1, 2, 3, 4];
// Function to render cart items on the page
function renderCartItems() {
    const cartItemsContainer = document.getElementById("cartItems");
    const totalAmountSpan = document.getElementById("totalAmount");

    // Clear existing content
    cartItemsContainer.innerHTML = "";

    let totalAmount = 0;
    console.log("rendering");
    productList.forEach( product => {
        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");

        const productName = document.createElement("h3");
        productName.textContent = product.productName;

        const productPrice = document.createElement("p");
        productPrice.textContent = `$${product.productPrice}`;

        // You can add an image if needed
        // const productImage = document.createElement("img");
        // productImage.src = product.image;
        // productImage.alt = product.name;

        // Append elements to the cart item
        cartItem.appendChild(productName);
        // cartItem.appendChild(productImage);
        cartItem.appendChild(productPrice);

        // Append the cart item to the cart items container
        cartItemsContainer.appendChild(cartItem);

        // Add the product price to the total amount
        totalAmount += parseInt(product.productPrice, 10);
    });


    // Update the total amount on the page
    totalAmountSpan.textContent = `$${totalAmount}`;
}

// Function to simulate making a payment
function makePayment() {
    var url = `http://localhost:9090/createOrder`;

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();
    const data = {"userId" : localStorage.getItem("userId"), "productList" : itemsInCart}
    const requestBody = JSON.stringify(data);
    // Configure it: specify the type of request and the URL
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // // Set up a callback function to handle the response
    // xhr.onload = function() {
    //     if (xhr.status >= 200 && xhr.status < 300) {
    //          return 
    //     } else {
    //         console.error('Request failed with status:', xhr.status);
    //         return null;
    //     }
    // };

    // Set up a callback function to handle network errors
    xhr.onerror = function() {
        console.error('Network error occurred');
    };

    // Send the request
    xhr.send(requestBody);
    alert("Payment Successful");
    window.location.href = 'productPage.html';
    localStorage.removeItem("itemsInCart");
}

var itemsInCart = [];
var productList = []
window.onload = function(){
   itemsInCart = JSON.parse( localStorage.getItem('itemsInCart') );
   console.log(itemsInCart);
   loggingdata();
   renderCartItems()
}



var response;
//function to get products
function getProductById(id){
    var url = `http://localhost:9090/getProductById?id=${id}`;

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure it: specify the type of request and the URL
    xhr.open('GET', url, false);
    xhr.setRequestHeader('Content-Type', 'application/json');

    // // Set up a callback function to handle the response
    // xhr.onload = function() {
    //     if (xhr.status >= 200 && xhr.status < 300) {
    //          return 
    //     } else {
    //         console.error('Request failed with status:', xhr.status);
    //         return null;
    //     }
    // };

    // Set up a callback function to handle network errors
    xhr.onerror = function() {
        console.error('Network error occurred');
    };

    // Send the request
    xhr.send();
    return JSON.parse(xhr.responseText);
 
}

function loggingdata(){

    itemsInCart.forEach( id => {
        productList.push( getProductById(id) ) ;
    })

}
